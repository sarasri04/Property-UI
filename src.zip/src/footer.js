import React from "react";

const Footer = () => (
  <footer className="footer">
      <h4>This App is developed and maintained by Cognizant!!</h4>
      <p>Level Two, Barangaroo Avenue, Sydney, 2000</p>

  </footer>
);

export default Footer;