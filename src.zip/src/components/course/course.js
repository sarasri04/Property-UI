import React from 'react';

const Course = () => (
    <div>
      <br></br>
      <br></br>
      Course Component
      <br></br>
      <br></br>
      <li>Java</li>
      <li>ReactJS</li>
    </div>
  );

  export default Course;